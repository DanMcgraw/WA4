# Fundamentals of Web Development, 2nd Edition
### Chapter 10 [JavaScript 3], Project 3 [Book CRM]
This project will use jQuery AJAX to consume and display JSON data. It will
also make use of a third-party JavaScript library to display charts of that data.

  
